var searchData=
[
  ['yellow',['yellow',['../da/d84/classaccounts_1_1models_1_1Template.html#ac4efd8e9fd9943923ce7d0a172037108',1,'accounts::models::Template']]]
];
