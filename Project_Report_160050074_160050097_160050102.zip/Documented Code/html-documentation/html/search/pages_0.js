var searchData=
[
  ['example_20project_20for_20django_5fprivate_5fchat',['Example Project for django_private_chat',['../md_Socializing_README.html',1,'']]]
];
