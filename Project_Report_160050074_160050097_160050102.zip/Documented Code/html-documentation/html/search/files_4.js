var searchData=
[
  ['forms_2epy',['forms.py',['../de/d43/accounts_2forms_8py.html',1,'']]],
  ['forms_2epy',['forms.py',['../d1/d7b/friendship_2forms_8py.html',1,'']]]
];
