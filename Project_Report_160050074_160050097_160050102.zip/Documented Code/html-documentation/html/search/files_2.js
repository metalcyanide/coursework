var searchData=
[
  ['channels_2epy',['channels.py',['../d1/d9f/channels_8py.html',1,'']]]
];
