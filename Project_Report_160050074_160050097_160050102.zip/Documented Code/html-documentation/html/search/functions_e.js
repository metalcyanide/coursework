var searchData=
[
  ['save',['save',['../d7/d8c/classfriendship_1_1models_1_1Friend.html#a5be087a95a824b445b3bd652fb989d3e',1,'friendship.models.Friend.save()'],['../dc/d75/classfriendship_1_1models_1_1Follow.html#ae3e45c26acdf0b5ff3117cc8b4f720a7',1,'friendship.models.Follow.save()'],['../d4/d81/classvote_1_1models_1_1VoteModel.html#af38b3f22b4754e5e8e150fa79e98ff5d',1,'vote.models.VoteModel.save()']]],
  ['sent_5frequests',['sent_requests',['../dd/d3c/classfriendship_1_1models_1_1FriendshipManager.html#a8f931da8ed2db2f6209020947da87ea9',1,'friendship::models::FriendshipManager']]],
  ['setup',['setUp',['../df/de1/classtest_1_1tests_1_1VoteTest.html#a04c36b0610f2f5ddabdad47aa3e7b665',1,'test::tests::VoteTest']]]
];
