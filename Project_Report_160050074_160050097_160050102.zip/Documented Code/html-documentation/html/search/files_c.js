var searchData=
[
  ['wsgi_2epy',['wsgi.py',['../d1/dfa/wsgi_8py.html',1,'']]]
];
