var searchData=
[
  ['alreadyexistserror',['AlreadyExistsError',['../d4/d79/classfriendship_1_1exceptions_1_1AlreadyExistsError.html',1,'friendship::exceptions']]],
  ['alreadyfriendserror',['AlreadyFriendsError',['../d8/de8/classfriendship_1_1exceptions_1_1AlreadyFriendsError.html',1,'friendship::exceptions']]]
];
