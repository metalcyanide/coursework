var searchData=
[
  ['_5fvotablemanager',['_VotableManager',['../d0/d2a/classvote_1_1managers_1_1__VotableManager.html',1,'vote::managers']]]
];
