var searchData=
[
  ['manage',['manage',['../da/df4/namespacemanage.html',1,'']]]
];
