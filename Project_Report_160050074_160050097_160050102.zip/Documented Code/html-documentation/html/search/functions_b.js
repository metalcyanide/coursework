var searchData=
[
  ['new_5fmessages_5fhandler',['new_messages_handler',['../d0/de0/namespacedjango__private__chat_1_1handlers.html#a88a8bdb3f6aaa1a49427485840c1371e',1,'django_private_chat::handlers']]]
];
