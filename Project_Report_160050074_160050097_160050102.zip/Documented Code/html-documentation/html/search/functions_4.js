var searchData=
[
  ['delete',['delete',['../d0/d2a/classvote_1_1managers_1_1__VotableManager.html#a634aa5dd0a5b68cf6a2b946185265006',1,'vote::managers::_VotableManager']]],
  ['delete_5farticle',['delete_article',['../db/d19/namespaceaccounts_1_1views.html#aacdd9c2ddd0a5246502ed80fbbb9aa80',1,'accounts::views']]],
  ['dept_5fposts',['dept_posts',['../db/d19/namespaceaccounts_1_1views.html#a3b935fcdb3726a0a0198a007f385041f',1,'accounts::views']]],
  ['down',['down',['../d0/d2a/classvote_1_1managers_1_1__VotableManager.html#a3afd30bb9e71bf7abd637f48086bfe01',1,'vote::managers::_VotableManager']]],
  ['down_5fvote_5farticle',['down_vote_article',['../db/d19/namespaceaccounts_1_1views.html#ac7b809aaf89550d5da6e1f6ed35c7de5',1,'accounts::views']]]
];
