var searchData=
[
  ['views_2epy',['views.py',['../d0/d2f/accounts_2views_8py.html',1,'']]],
  ['views_2epy',['views.py',['../d1/ded/vote_2views_8py.html',1,'']]],
  ['views_2epy',['views.py',['../dc/d74/test_2views_8py.html',1,'']]],
  ['views_2epy',['views.py',['../d3/d42/friendship_2views_8py.html',1,'']]],
  ['views_2epy',['views.py',['../d5/d79/django__private__chat_2views_8py.html',1,'']]],
  ['views_2epy',['views.py',['../dd/d32/custom__app_2views_8py.html',1,'']]]
];
