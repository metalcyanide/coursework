var searchData=
[
  ['view_5ffriends',['view_friends',['../db/d0a/namespacefriendship_1_1views.html#a7c41851cfe1e2d4f2dd5bc710ca4dbad',1,'friendship::views']]],
  ['view_5fprofile',['view_profile',['../db/d19/namespaceaccounts_1_1views.html#a871edf1aacffcdeef42e8de873e489d6',1,'accounts::views']]],
  ['vote',['vote',['../d0/d2a/classvote_1_1managers_1_1__VotableManager.html#a1df2af1d4ad5130cb209543d5f7e7110',1,'vote::managers::_VotableManager']]],
  ['vote_5fby',['vote_by',['../d0/d2a/classvote_1_1managers_1_1__VotableManager.html#a808c88ae1ac15f6d9a103662ac03a211',1,'vote::managers::_VotableManager']]],
  ['votes_5ffor',['votes_for',['../da/d05/classvote_1_1models_1_1Vote.html#add1adaf5d686cc7375a38ecd9cfd36e2',1,'vote::models::Vote']]]
];
