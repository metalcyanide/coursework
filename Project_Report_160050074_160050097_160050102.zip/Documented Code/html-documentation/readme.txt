Need to open index.html in html folder to get the project documentation in html form.
