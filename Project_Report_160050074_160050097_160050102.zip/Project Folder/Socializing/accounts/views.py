from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth.forms import UserCreationForm, UserChangeForm, PasswordChangeForm
from django.contrib.auth.models import User
from accounts.forms import EditProfleForm, PostForm, TemplateForm, ProfileForm, UserCreationForm2
from .models import Post, Template, Profile, DeptPost
from django.contrib.auth.decorators import login_required
from django.contrib.auth import update_session_auth_hash
from django import forms

@login_required
## @brief This function directs the user to his/her homepage
# @param httprequest
def home(request):
	posts = Post.objects.order_by('-uploaded_at')
	args = {'user': request.user, 'posts' : posts}
	return render(request,'accounts/home.html',args)

@login_required
## @brief This function directs the user to his/her news feed
# @param httprequest
def my_posts(request):
	posts = Post.objects.order_by('-uploaded_at')
	args = {'user': request.user, 'posts' : posts}
	return render(request,'accounts/my_posts.html',args)

@login_required
## @brief This function directs the user to his/her department posts page
# @param httprequest
def dept_posts(request):
	post1 = Post.objects.order_by('-vote_score')[0]
	posts = DeptPost.objects.order_by('-uploaded_at')
	args = {'user': request.user, 'posts' : posts, 'post1' : post1}
	return render(request,'accounts/dept_posts.html',args)

## @brief This function directs the user to the registration page
# @param httprequest
def register(request):
	if request.method == 'POST':
		form = UserCreationForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('/accounts/login')
	else:
		form = UserCreationForm()
		args = {'form': form}
		return render(request, 'accounts/reg_form.html', args)



@login_required
## @brief This function doesn't do anything
def edit_deeper_profile(request):
	if request.method == 'POST':
		form = ProfileForm(request.POST, request.FILES, instance=request.user.profile)
		if form.is_valid():
			form.save()
			return redirect('/accounts')
	else:
		form = ProfileForm(request.FILES, instance=request.user.profile)
		args = {'form': form}
		return render(request, 'accounts/template.html', args)


@login_required
## @brief This function directs the user to his/her edit profile page
# @param httprequest
def edit_profile(request):
	if request.method == 'POST':
		form1 =  EditProfleForm(request.POST, instance=request.user)
		form2 = ProfileForm(request.POST, request.FILES, instance=request.user.profile)
		if (form1.is_valid() and form2.is_valid()):
			form1.save()
			form2.save()
			args = {'user': request.user}
			return redirect('/accounts/edit_profile')
			
	else:
		form1 =  EditProfleForm(instance=request.user)
		form2 = ProfileForm( instance=request.user.profile)
		form1.fields['password'].widget = forms.HiddenInput()
		args = {'form1': form1,'form2': form2}
		return render(request, 'accounts/edit_profile.html', args)

@login_required
## @brief This function directs the user to the page where he/she can publish a new post
# @param httprequest
def post_new(request):
	if request.method == 'POST':
		form = PostForm(request.POST, request.FILES)
		if form.is_valid():
			post=form.save(commit=False)
			post.author=request.user
			post.save()
			return redirect('/accounts')
	else:
		form = PostForm()
		args = {'form': form,'user': request.user}
		return render(request, 'accounts/post_new.html', args)
@login_required
## @brief This function directs the user to his/her template page(where the user can change his/her template)
# @param httprequest
def template(request):
	if request.method == 'POST':
		form = TemplateForm(request.POST, request.FILES,instance=request.user.template)
		if form.is_valid():
			form.save()
			return redirect('/accounts')
	else:
		form = TemplateForm(instance=request.user.template)
		args = {'form': form}
		return render(request, 'accounts/template.html', args)
## @brief This function is used while upvoting a certain post
# @param httprequest
# @param article_id(the id of the article which is to be upvoted)
def up_vote_article(request, article_id):
    article = Post.objects.get(pk=article_id)
    article.votes.up(request.user.pk)
    return redirect('/accounts/#intro')

## @brief This function is used while downvoting a certain post
# @param httprequest
# @param article_id(the id of the article which is to be downvoted)
def down_vote_article(request, article_id):
    article = Post.objects.get(pk=article_id)
    article.votes.down(request.user.pk)
    return redirect('/accounts/#intro')

## @brief This function is used to delete a certain post
# @param httprequest
# @param article_id(the id of the article which is to be deleted)
def delete_article(request, article_id):
    article = Post.objects.get(pk=article_id)
    article.delete()
    return redirect('/accounts/my_posts/#intro')

## @brief This function is used to change the password
# @param httprequest
def change_password(request):
	if request.method == 'POST':
		form = PasswordChangeForm(data=request.POST, user=request.user)
		if form.is_valid():
			form.save()
			update_session_auth_hash(request, form.user)
			args = {'user': request.user}
			#users = User.objects.all().select_related('profile')
			return render(request, 'accounts/profile.html', args)
		else :
			form = PasswordChangeForm(user=request.user)
			args = {'form': form}
			return render(request, 'accounts/change_password.html', args)
	else:
		form = PasswordChangeForm(user=request.user)
		args = {'form': form}
		return render(request, 'accounts/change_password.html', args)
## @brief This function directs the user to a particluar person's profile page
# @param httprequest
# @param user1(the user whose profile is to be viewed)
def view_profile(request,user1):
	args = {'user' : User.objects.filter(pk=user1)[0]}
	return render(request, 'accounts/view_profile.html', args)



