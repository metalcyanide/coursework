from django.conf.urls import url, include
from . import views
from django.contrib.auth.views import login, logout

urlpatterns = [
	url(r'^$',views.home),
	url(r'^logout/', logout, {'template_name': 'accounts/logout.html'}),
	url(r'^register/', views.register, name='register'),
	url(r'^edit_profile/', views.edit_profile, name='edit_profile'),
	url(r'^my_posts/', views.my_posts, name='my_posts'),
	url(r'^dept_posts/', views.dept_posts, name='dept_posts'),
	
	url(r'^view_profile/(?P<user1>\d+)/', views.view_profile, name='view_profile'),
	url(r'^post_new/', views.post_new, name='post_new'),
	url(r'^template/', views.template, name='template'),
	url(r'^change_password/', views.change_password, name='change_password'),
	url(r'^login/', login, {'template_name': 'accounts/login.html'}),
	url(r'^friendship/', include('friendship.urls')),
	url(r'^chat/', include('django_private_chat.urls')),
    url(r'^chat/', include('custom_app.urls')),
    url(r'^vote/', include('test.urls')),
    url(r'^(?P<article_id>[0-9]+)/upvote/', views.up_vote_article, name='up_vote_article'),
    url(r'^(?P<article_id>[0-9]+)/downvote/', views.down_vote_article, name='down_vote_article'),
    url(r'^(?P<article_id>[0-9]+)/delete/', views.delete_article, name='delete_article'),
] 
