from __future__ import unicode_literals
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from vote.models import VoteModel
from django.utils import timezone

## @package pyexample


## @brief This class represents the posts of the user
class Post(VoteModel,models.Model):
    ## This member variable represents the author of the post
    author = models.ForeignKey('auth.User')
    ## This member variable represents the title of the post
    title = models.CharField(max_length=200)
    ## This member variable represents the body of the post
    text = models.TextField()
    ## This member variable represents the date it was created
    created_date = models.DateTimeField(
            default=timezone.now)
    ## This member variable represents the data it was created
    published_date = models.DateTimeField(
            blank=True, null=True)
    ## This member variable represents the document which has is uploaded during post
    document = models.ImageField(upload_to='images/',blank=True)
    ## This member variable represents the time at which the document was uploaded
    uploaded_at = models.DateTimeField(auto_now_add=True)

    ## @brief This function publishes the post
    def publish(self):
        self.published_date = timezone.now()
        self.save()

    ## @brief Returns the post's title
    def __str__(self):
        return self.title

## @brief This class represents department posts
class DeptPost(VoteModel,models.Model):
    ## This member variable represents the author of the post
    author = models.ForeignKey('auth.User')
    ## This member variable represents the title of the post
    title = models.CharField(max_length=200)
    ## This member variable represents the body of the post
    text = models.TextField()
    ## This member variable represents the date it was created
    created_date = models.DateTimeField(
            default=timezone.now)
    ## This member variable represents the data it was created
    published_date = models.DateTimeField(
            blank=True, null=True)
    ## This member variable represents the document which has is uploaded during post
    document = models.ImageField(upload_to='images/',blank=True)
    ## This member variable represents the time at which the document was uploaded
    uploaded_at = models.DateTimeField(auto_now_add=True)

    ## @brief This function publishes the post
    def publish(self):
        self.published_date = timezone.now()
        self.save()
    ## @brief Returns the post's title
    def __str__(self):
        return self.title

## @brief This class represents the profile of the user
class Profile(models.Model):
    ## This member variable represents the profile's user
    user=models.OneToOneField(User)
    ## This member variable represents the city of the user
    City = models.CharField(max_length=200,default='')
    ## This member variable represents the school of the user
    School = models.CharField(max_length=20,default='')
    ## This member variable represents the college of the user
    College = models.CharField(max_length=20,default='')
    ## This member variable gives brief description of the user
    About_me = models.CharField(max_length=20,default='')
    ## This member represents the profile picture of the user
    document = models.ImageField(upload_to='profile/',default='')


## @brief Creates the profile of the user
# @param User
def create_profile(sender, **kwargs):
    if kwargs['created']:
        user_profile = Profile.objects.create(user=kwargs['instance'])
post_save.connect(create_profile, sender=User)


## @brief This class represents the various themes(text colour and background image) to the user
class Template(models.Model):
    white='white'
    blue='blue'
    yellow='yellow'
    green= 'green'
    CHOICES = (
        (white, 'white'),
        (yellow, 'yellow'),
        (blue, 'blue'),
        (green, 'green'),
    )
    ## This member variable represents the user
    user=models.OneToOneField(User)
    ## This member variable represents the text colour of the user
    colour = models.CharField(max_length=20,choices=CHOICES,default=white)
    ## This member function represents the background image of the user's home(essentially all the pages the user visits)
    document = models.ImageField(upload_to='bg/',blank=True)

## @brief Used to change the tempplate of the user
# @param User
def create_template(sender, **kwargs):
    if kwargs['created']:
        user_template = Template.objects.create(user=kwargs['instance'])
post_save.connect(create_template, sender=User)