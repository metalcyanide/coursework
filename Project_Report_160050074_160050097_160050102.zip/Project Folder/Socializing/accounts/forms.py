from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from .models import Post, Template, Profile
from django.utils.translation import ugettext_lazy as _

## @brief This class represents the registration form for the user 
class UserCreationForm2(UserCreationForm):
	
	class Meta:
		model = User
		fields = [		
		'username',
		'password1',
		'password2',
		'email',
		'first_name',
		'last_name'		
		]



## @brief This class represents the form where the user can edit his/her personal details
class EditProfleForm(UserChangeForm):
	
	class Meta:
		model = User
		fields = [
		
		'first_name',
		'last_name',
		'email',
		'password'
		]

## @brief This class represents the form where the user can create a new post
class PostForm(forms.ModelForm):

	class Meta:
		model = Post
		fields = [
		'title',
		'text',
		'document',
		]
		labels = {
		'document' : _('image')
		}



## @brief This class represents the form used to select the template
class TemplateForm(forms.ModelForm):

	class Meta:
		model = Template
		fields = [
		'colour',
		'document',
		]
		labels = {
		'document' : _('image')
		}

## @brief This class represents the profile of the user
class ProfileForm(forms.ModelForm):

	class Meta:
		model = Profile
		fields = [
		'City',
		'School',
		'College',
		'About_me',
		'document',
		]
		labels = {
		'document' : _('image')
		}

## @brief This class represents the form used to change the password of the user
class PasswordChange(forms.Form):
	new_password = forms.CharField(label='new_password',max_length=100)