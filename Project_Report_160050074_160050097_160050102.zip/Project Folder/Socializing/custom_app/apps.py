from django.apps import AppConfig


class CustomAppConfig(AppConfig):
    name = 'custom_app'
